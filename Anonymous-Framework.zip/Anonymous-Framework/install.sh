function Install() {

apt-get upgrade
apt-get update
apt-get install tor
apt-get install python
apt-get install python2

}
Install
chmod +x *
figlet -f slant "Installed"
sleep 0.5
clear
ls

